/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   map_validation.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sdalaty <sdalaty@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/27 12:12:49 by sdalaty           #+#    #+#             */
/*   Updated: 2024/07/30 11:15:29 by sdalaty          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../so_long.h"

void	f(void)
{
	free_map();
	exit(1);
}

void	walls_valide(void)
{
	int	i;

	i = 0;
	while (i < g_var.map.size.width)
	{
		if (g_var.map.data[0][i] != '1' || g_var.map.data[g_var.map.size.height
			- 1][i] != '1')
		{
			free_map();
			ft_printf("Invalide map\n");
			f();
		}
		i++;
	}
	i = 0;
	while (i < g_var.map.size.height)
	{
		if (g_var.map.data[i][0] != '1'
			|| g_var.map.data[i][g_var.map.size.width - 1] != '1')
		{
			ft_printf("Invalide map\n");
			f();
		}
		i++;
	}
}

void	is_rectangular(void)
{
	int	i;

	i = 0;
	while (i < g_var.map.size.height)
	{
		if ((int)ft_strlen(g_var.map.data[i]) != g_var.map.size.width)
		{
			free_map();
			ft_printf("not rectangular");
			exit(1);
		}
		i++;
	}
}

int	is_valid(char c)
{
	return (c == 'E' || c == 'P' || c == 'C' || c == '1' || c == '0');
}

void	collectibale_validation(void)
{
	int	i;
	int	j;
	int	collect;

	collect = 0;
	i = 0;
	while (i < g_var.map.size.height)
	{
		j = 0;
		while (j < g_var.map.size.width)
		{
			if (!is_valid(g_var.map.data[i][j]))
				free_exit("invalid character");
			if (g_var.map.data[i][j] == 'C')
				collect++;
			j++;
		}
		i++;
	}
	if (collect == 0)
		c();
	g_var.game.count_collec = collect;
}

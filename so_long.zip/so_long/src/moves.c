/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   moves.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sdalaty <sdalaty@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/27 12:13:01 by sdalaty           #+#    #+#             */
/*   Updated: 2024/07/30 10:21:47 by sdalaty          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../so_long.h"

void	move_left(void)
{
	g_var.map.data[g_var.img.pos.height][g_var.img.pos.width] = '0';
	g_var.img.pos.width -= 1;
	g_var.map.data[g_var.img.pos.height][g_var.img.pos.width] = 'P';
	g_var.game.count_steps++;
	g_var.img.spt_path = "./img/sprite2.xpm";
}

void	move_right(void)
{
	g_var.map.data[g_var.img.pos.height][g_var.img.pos.width] = '0';
	g_var.img.pos.width += 1;
	g_var.map.data[g_var.img.pos.height][g_var.img.pos.width] = 'P';
	g_var.game.count_steps++;
	g_var.img.spt_path = "./img/sprite1.xpm";
}

void	move_up(void)
{
	g_var.map.data[g_var.img.pos.height][g_var.img.pos.width] = '0';
	g_var.img.pos.height -= 1;
	g_var.map.data[g_var.img.pos.height][g_var.img.pos.width] = 'P';
	g_var.game.count_steps++;
	g_var.img.spt_path = "./img/sprite1.xpm";
}

void	move_down(void)
{
	g_var.map.data[g_var.img.pos.height][g_var.img.pos.width] = '0';
	g_var.img.pos.height += 1;
	g_var.map.data[g_var.img.pos.height][g_var.img.pos.width] = 'P';
	g_var.game.count_steps++;
	g_var.img.spt_path = "./img/sprite1.xpm";
}

void	handle_up(void)
{
	if (g_var.map.data[g_var.img.pos.height - 1]
		[g_var.img.pos.width] == 'E')
		check_collect();
	else if (g_var.map.data[g_var.img.pos.height - 1]
		[g_var.img.pos.width] != '1')
		move_up();
}

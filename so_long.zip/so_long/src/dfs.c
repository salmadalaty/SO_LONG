/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   dfs.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sdalaty <sdalaty@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/27 12:11:12 by sdalaty           #+#    #+#             */
/*   Updated: 2024/08/03 09:23:41 by sdalaty          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../so_long.h"

void	dfs(char **data, t_position start, t_position size, int **visited)
{
	t_position	next_positions[4];

	next_positions[0].width = start.width;
	next_positions[0].height = start.height + 1;
	next_positions[1].width = start.width;
	next_positions[1].height = start.height - 1;
	next_positions[2].width = start.width + 1;
	next_positions[2].height = start.height;
	next_positions[3].width = start.width - 1;
	next_positions[3].height = start.height;
	if (start.height < 0 || start.height >= size.height || start.width < 0
		|| start.width >= size.width
		|| data[start.height][start.width] == '1'
		|| visited[start.height][start.width])
		return ;
	visited[start.height][start.width] = 1;
	dfs(data, next_positions[0], size, visited);
	dfs(data, next_positions[1], size, visited);
	dfs(data, next_positions[2], size, visited);
	dfs(data, next_positions[3], size, visited);
}

void	moves(int key)
{
	if (key == KEY_A)
		handle_left();
	else if (key == KEY_D)
		handle_right();
	else if (key == KEY_S)
		handle_down();
	else if (key == KEY_W)
		handle_up();
}

void	handle_left(void)
{
	if (g_var.map.data[g_var.img.pos.height]
		[g_var.img.pos.width - 1] == 'E')
		check_collect();
	else if (g_var.map.data[g_var.img.pos.height]
		[g_var.img.pos.width - 1] != '1')
		move_left();
}

void	handle_right(void)
{
	if (g_var.map.data[g_var.img.pos.height]
		[g_var.img.pos.width + 1] == 'E')
		check_collect();
	else if (g_var.map.data[g_var.img.pos.height]
		[g_var.img.pos.width + 1] != '1')
		move_right();
}

void	handle_down(void)
{
	if (g_var.map.data[g_var.img.pos.height + 1]
		[g_var.img.pos.width] == 'E')
		check_collect();
	else if (g_var.map.data[g_var.img.pos.height + 1]
		[g_var.img.pos.width] != '1')
		move_down();
}

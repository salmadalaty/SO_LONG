/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   game.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sdalaty <sdalaty@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/27 12:11:22 by sdalaty           #+#    #+#             */
/*   Updated: 2024/07/27 15:49:31 by sdalaty          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../so_long.h"

void	init_position(void)
{
	int	i;
	int	j;

	i = 0;
	while (i < g_var.map.size.height)
	{
		j = 0;
		while (j < g_var.map.size.width)
		{
			if (g_var.map.data[i][j] == 'P')
			{
				g_var.img.pos.width = j;
				g_var.img.pos.height = i;
			}
			j++;
		}
		i++;
	}
}

void	contains_one_exit(void)
{
	int	exit_count;
	int	start_count;
	int	i;
	int	j;

	start_count = 0;
	exit_count = 0;
	i = 0;
	while (i < g_var.map.size.height)
	{
		j = 0;
		while (j < g_var.map.size.width)
		{
			if (g_var.map.data[i][j] == 'E')
				exit_count++;
			if (g_var.map.data[i][j] == 'P')
				start_count++;
			j++;
		}
		i++;
	}
	if (start_count != 1 || exit_count != 1)
		e();
}

void	e(void)
{
	ft_printf("error E or P");
	exit(1);
}

void	check_map(void)
{
	walls_valide();
	is_rectangular();
	collectibale_validation();
	contains_one_exit();
	has_valid_path();
}

void	c(void)
{
	free_map();
	ft_printf("NO collectible");
	exit(1);
}

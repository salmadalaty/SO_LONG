/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sdalaty <sdalaty@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/30 10:18:51 by sdalaty           #+#    #+#             */
/*   Updated: 2024/07/30 16:01:22 by sdalaty          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../so_long.h"

void	initialize(void)
{
	g_var.mlx = NULL;
	g_var.win = NULL;
	g_var.game.count_collec = 0;
	g_var.game.count_steps = 0;
	g_var.map.data = NULL;
	g_var.map.size.height = 0;
	g_var.map.size.width = 0;
	g_var.img.img_ptr = NULL;
	g_var.img.spt_path = "./img/sprite.xpm";
	g_var.img.size.width = 0;
	g_var.img.size.height = 0;
	g_var.img.pos.width = 0;
	g_var.img.pos.height = 0;
	g_var.img.data = NULL;
}

void	check_collect(void)
{
	if (count_collec() == 0)
		free_exit("\e[32m\e[5m\e[1m🎉 CONGRATULATIONS 🎉\n!!!! You WON !!!!\e[0m\n");
	else
		ft_printf("\e[35m\e[1m ⚠️  Please, collect all the cheese!!!\e[0m\n");
}

void	print_error_message(char *str)
{
	ft_printf(str);
	exit(1);
}
